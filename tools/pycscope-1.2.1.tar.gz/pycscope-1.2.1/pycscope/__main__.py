"""PyCscope's main entrypoint."""
import sys
from pycscope import main
sys.exit(main())
